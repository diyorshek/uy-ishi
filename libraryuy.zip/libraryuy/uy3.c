#include <stdio.h>
#include <stdbool.h>


bool bormi(int a[], int s, int n) {
    for (int i = 0; i < s; i++) {
        if (a[i] == n) {
            return true;
        }
    }
    return false;
}

int main() {
    int s, n;
    printf("Massiv sonini ayting: ");
    scanf("%d", &s);

    int a[s];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < s; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("Qidirilayotgan sonni kiriting: ");
    scanf("%d", &n);

    if (bormi(a, s, n)) {
        printf("True\n");
    } else {
        printf("False\n");
    }

    return 0;
}
