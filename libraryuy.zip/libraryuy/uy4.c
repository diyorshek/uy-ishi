#include <stdio.h>


int indeks(int a[], int s, int index) {
    if (index >= 0 && index < s) {
        return a[index];
    } else {
        return 0;
    }
}

int main() {
    int s, index;
    printf("Massiv sonini ayting: ");
    scanf("%d", &s);

    int a[s];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < s; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("Qidirilayotgan indeksni kiriting: ");
    scanf("%d", &index);

    int result = indeks(a, s, index);
    printf("Natija: %d\n", result);

    return 0;
}
