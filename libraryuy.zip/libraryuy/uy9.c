#include <stdio.h>

void teskari(int massiv[], int s) {
    int teskari[s];
    for (int i = 0; i < s; i++) {
        teskari[i] = massiv[s - 1 - i];
    }

    
    printf("Teskari massiv: ");
    for (int i = 0; i < s; i++) {
        printf("%d ", teskari[i]);
    }
    printf("\n");
}

int main() {
    int s;
    printf("Massiv sonini kiriting: ");
    scanf("%d", &s);

    int massiv[s];
    printf("son kiriting:\n");
    for (int i = 0; i < s; i++) {
        printf("a[%d] : ", i );
        scanf("%d", &massiv[i]);
    }

    teskari(massiv, s);

    return 0;
}
