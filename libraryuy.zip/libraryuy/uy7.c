#include <stdio.h>


void anibga(int a[], int size, int index, int value) {
    if (index >= 0 && index < size) {
        a[index] = value;
    }
}

int main() {
    int size, index, value;
    printf("Massiv sonini ayting: ");
    scanf("%d", &size);

    int a[size];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < size; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("a =  : ");
    scanf("%d", &index);
    printf("b =  ");
    scanf("%d", &value);

    anibga(a, size, index, value);

    printf("Yangilangan massiv: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}
