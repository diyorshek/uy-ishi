#include <stdio.h>


void joylashtir(int a[], int s, int n) {
    
    for (int i = s; i > 0; i--) {
        a[i] = a[i - 1];
    }
   
    a[0] = n;
}

int main() {
    int s, n;
    printf("Massiv sonini ayting: ");
    scanf("%d", &s);

    int a[s + 1]; 
    printf("Son kiriting:\n");
    
    for (int i = 0; i < s; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("yang son qoyamiz: ");
    scanf("%d", &n);

    joylashtir(a, s, n);
    s++; 

    printf("Yangi massiv: ");
    for (int i = 0; i < s; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}
