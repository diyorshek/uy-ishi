#include <stdio.h>

int min, max;

void minmax(int a[], int n) {
    min = a[0];
    max = a[0];

    for (int i = 1; i < n; i++) {
        if (a[i] < min) {
            min = a[i];
        }
        if (a[i] > max) {
            max = a[i];
        }
    }
}

int main() {
    int n;
    printf("Massiv sonini ayting: ");
    scanf("%d", &n);

    int a[n];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    minmax(a, n);

    printf("Max = %d\n", max);
    printf("Min = %d\n", min);

    return 0;
}
