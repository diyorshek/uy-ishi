#include <stdio.h>


float ortacha(int a[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return (float)sum / n;
}

int main() {
    int n;
    printf("Massiv sonini ayting: ");
    scanf("%d", &n);

    int a[n];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    float average = ortacha(a, n);
    printf("O'rtacha qiymat: %.2f\n", average);

    return 0;
}
