#include <stdio.h>


void obtashi(int a[], int *size, int index) {
    if (index >= 0 && index < *size) {
        for (int i = index; i < *size - 1; i++) {
            a[i] = a[i + 1];
        }
        (*size)--;
    }
}

int main() {
    int size, index;
    printf("Massiv sonini ayting: ");
    scanf("%d", &size);

    int a[size];
    printf("Son kiriting:\n");
    
    for (int i = 0; i < size; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("a = ");
    scanf("%d", &index);

    obtashi(a, &size, index);

    printf("Yangi massiv: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}
