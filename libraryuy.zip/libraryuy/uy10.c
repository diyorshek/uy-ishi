#include <stdio.h>

int sonp(int massiv[], int s, int n) {
    int z = 0;
    for (int i = 0; i < s; i++) {
        if (massiv[i] == n) {
            z++;
        }
    }
    return z;
}

int main() {
    int s, n;
    printf("Massiv sonini kiriting: ");
    scanf("%d", &s);

    int massiv[s];
    printf("son kiriting:\n");
    for (int i = 0; i < s; i++) {
        printf("a[%d] : ", i);
        scanf("%d", &massiv[i]);
    }

    printf("n : ");
    scanf("%d", &n);

    int soni = sonp(massiv, s, n);
    printf("%d marta",soni);

    return 0;
}
