#include<stdio.h>
#include<stdlib.h>
#include<time.h>


int main (){
    srand(time(NULL));
    int a[100];

    int n; printf("n= "); scanf("%d", &n);
    for (int i=0; i<n; i++ ) {

       a[i]=rand()%10+1;
    }
    for (int i=0; i<n; i++ ) {
        printf("a[%d] = %d\n",i,a[i]);

    }
}