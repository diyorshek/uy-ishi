#include<stdio.h>

int main (){
    int a[100];

    int n; printf("n= "); scanf("%d", &n);
    for (int i=0; i<n; i++ ) {

        printf("a[%d] = ",i);
        scanf ("%d",&a[i]);

    }
    for (int i=0; i<n; i++ ) {
        printf("a[%d] = %d\n",i,a[i]);

    }
}